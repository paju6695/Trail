package com.test;

public class Display {

	public static void main(String[] args) {
		
		System.out.println("hellow");

	}

}
